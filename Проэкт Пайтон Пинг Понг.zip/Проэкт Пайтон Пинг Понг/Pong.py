import pygame as pg
import random
import time
pg.init()
win_width, win_height = 900, 550
window = pg.display.set_mode((win_width, win_height))
pg.display.set_caption("Project Glaxy")
class GameSprite:
    def __init__(self, image, x, y, width, height, speed):
        self.width = width
        self.height = height
        self.speed = speed
        self.image = pg.transform.scale(pg.image.load(image), (width, height))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))
class Player(GameSprite):
    def control1(self):
        keys = pg.key.get_pressed()
        if keys[pg.K_s] and self.rect.y < 600 - 250:
            self.rect.y += self.speed
        if keys[pg.K_w] and self.rect.y > 0:
            self.rect.y -= self.speed
    def control2(self):
        keys = pg.key.get_pressed()
        if keys[pg.K_DOWN] and self.rect.y < 600 - 250:
            self.rect.y += self.speed
        if keys[pg.K_UP] and self.rect.y > 0:
            self.rect.y -= self.speed
class Ball(GameSprite):
    def move(self):
        global x2, y2, player1, player2, score1, score2, i
        self.rect.x += x2
        self.rect.y += y2
        if pg.sprite.collide_rect(player2, self):
            x2 = -5
        if pg.sprite.collide_rect(player1, self):
            x2 = 5
        if self.rect.y < 0:
            y2 = 5
        if self.rect.y > 550:
            y2 = -5
        if self.rect.x == 0:
            score2 += 1
            self.rect.x = 400
        if self.rect.x > win_width - self.width:
            score1 += 1
            self.rect.x = 400


x2, y2 = 5, 5
score1 = 0
score2 = 0
player1_win = "image/Win1Player.png"
player2_win = "image/Win2Player.png"
back = GameSprite("image/фон.png", 0, 0, 900, 550, 0)
player1 = Player("image/GreenPensil.png", 0, 225, 25, 190, 7 )
player2 = Player("image/RedPencil.png", 850, 225, 25, 190, 7 )
ball = Ball("image/Ball1.png", 450, 275, 25, 25, 5)
game = True
bg2 = GameSprite(player2_win, 0, 0, 900, 550, 0)
bg = GameSprite(player1_win, 0, 0, 900, 550, 0)
winplayer1 = 0
winplayer2 = 0
while game:
        
    pg.time.Clock().tick(144)
    for i in pg.event.get():
        if i.type == pg.QUIT:
            exit()
    back.reset()
    player1.reset()
    player2.reset()
    player1.control1()
    player2.control2()
    ball.reset()
    ball.move()
    
    if score1 > 3:
        bg.reset()
        keys = pg.key.get_pressed()
        if keys[pg.K_SPACE]:
            winplayer1 += 1     
            score1 = 0
            score2 = 0
            
            
    if score2 > 3:
        bg2.reset()
        keys = pg.key.get_pressed()
        if keys[pg.K_SPACE]:
            winplayer2 += 1
            score2 = 0
            score1 =0
            

    
    
    label = pg.font.SysFont("Arial", 25).render(F"Player1 score : {score1}", True, "White")
    window.blit(label,(20,20))
    label = pg.font.SysFont("Arial", 25).render(F"Number of wins 1 Player : {winplayer1}", True, "White")
    window.blit(label,(20,40))
    label = pg.font.SysFont("Arial", 25).render(F"Player2 score : {score2}", True, "White")
    window.blit(label,(600,20))
    label = pg.font.SysFont("Arial", 25).render(F"Number of wins 1 Player : {winplayer2}", True, "White")
    window.blit(label,(600,40))
    

    pg.display.flip()
while True:
    for i in pg.event.get():
        if i.type == pg.QUIT:
            exit()
    
    pg.display.flip()